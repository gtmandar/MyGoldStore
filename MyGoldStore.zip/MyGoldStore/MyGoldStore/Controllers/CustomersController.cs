﻿using Microsoft.AspNetCore.Mvc;
using MyGoldStore.Controllers.Data;
using MyGoldStore.Models.Domain;
using MyGoldStore.Models;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace MyGoldStore.Controllers
{
    public class CustomersController : Controller
    {
        private readonly MVCDemoDbContext mvcDemoDbContext;

        public CustomersController(MVCDemoDbContext mvcDemoDbContext)
        {
            this.mvcDemoDbContext = mvcDemoDbContext;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var customers = await mvcDemoDbContext.Customers.ToListAsync();
            return View(customers);
        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();

        }

        [HttpPost]
        public async Task<IActionResult> Add(AddCustomerViewModel addCustomerRequest)
        {
            
                var customer = new Customer()
                {
                    id = Guid.NewGuid(),
                    name = addCustomerRequest.name,
                    ornaments = addCustomerRequest.ornaments,
                    weight = addCustomerRequest.weight,
                    price = addCustomerRequest.price,
                    phone = addCustomerRequest.phone,
                    orderDate = addCustomerRequest.orderDate,
                    deliveryDate = addCustomerRequest.deliveryDate,
                    createdBy = addCustomerRequest.createdBy,
                    createdAt = DateTime.Now

                };               
                await mvcDemoDbContext.Customers.AddAsync(customer);
                await mvcDemoDbContext.SaveChangesAsync();
                return RedirectToAction("Add");
           
        }


        [HttpGet]
        public async Task<IActionResult> View(Guid id) 
        {
           var customer = await mvcDemoDbContext.Customers.FirstOrDefaultAsync(x => x.id == id);
            if (customer != null)
            {
                var viewmodel = new UpdateCustomerViewModel()
                {
                    id = customer.id,
                    Name = customer.name,
                    ornaments = customer.ornaments,
                    weight = customer.weight,
                    price = customer.price,
                    phone = customer.phone,
                    orderDate = customer.orderDate,
                    deliveryDate = customer.deliveryDate,
                    createdBy = customer.createdBy

                };
                //return View(viewmodel);     
                return await Task.Run(() => View("View",viewmodel));
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> View(UpdateCustomerViewModel model)
        {
            var customer = await mvcDemoDbContext.Customers.FindAsync(model.id);
            if (customer != null)
            {
                customer.name= model.Name;
                customer.ornaments= model.ornaments;
                customer.weight= model.weight;
                customer.price= model.price;
                customer.phone= model.phone;
                customer.orderDate = model.orderDate;
                customer.deliveryDate = model.deliveryDate;

                await mvcDemoDbContext.SaveChangesAsync();

                return RedirectToAction("Index");
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> Delete(UpdateCustomerViewModel model)
        {
            var customer= await mvcDemoDbContext.Customers.FindAsync(model.id);

            if(customer != null)
            {
                mvcDemoDbContext.Customers.Remove(customer);
                await mvcDemoDbContext.SaveChangesAsync();

                return RedirectToAction("Index");

            }
            return RedirectToAction("Index");
        }


    }
}
