﻿namespace MyGoldStore.Models
{
    public class AddCustomerViewModel
    {
        public String? name { get; set; }
        public String? ornaments { get; set; }

        public long weight { get; set; }
        public long price { get; set; }
        public String? phone { get; set; }
        public DateTime orderDate { get; set; }
        public DateTime deliveryDate { get; set; }
        public string? createdBy { get; set; }
        public string? successMessage { get; set; }

    }
}
